
#ifndef WINDMILL_H
#define WINDMILL_H


class WindMill
{
    public:

        WindMill();
        WindMill(float wx,float wy,float wz,float angle);
        void render();
        //virtual ~WindMillBee();

    protected:

    private:
        float wx,wy,wz;
        float angle;
        void drawWindmill();
};

#endif // WINDMILL_H

