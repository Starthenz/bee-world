#ifndef FLOWER_H
#define FLOWER_H


class Flower
{
    public:
        Flower();
        //virtual ~Flower();
        void drawFlower();

    protected:

    private:
};

#endif // FLOWER_H
