#include "Flower.h"
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <GL/gl.h>
#include <stdlib.h>
#include <stdio.h>

Flower::Flower()
{
    //ctor
}

/*Flower::~Flower()
{
    //dtor
}*/
void Flower::drawFlower(){

//glLoadIdentity();                 // Reset the model-view matrix
GLUquadricObj*qd;
/*glClipPlane(GL_CLIP_PLANE1,clip_plane1);
glEnable(GL_CLIP_PLANE1);*/
// drawing a sphere
qd=gluNewQuadric();


glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(1.5f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.25f,0.25f,2.25f,15,15);
glPopMatrix();

//pink flower
//double clip_plane1[]={0.0,0.0,-1.0,0.5};
//glClipPlane(GL_CLIP_PLANE1,clip_plane1);
//glEnable(GL_CLIP_PLANE1);
glTranslatef(1.5f, 0.0f, -7.0f);  // Move right and into the screen
glColor3f(1.0f,0.0f,1.0f);
gluSphere(qd,0.9f,30,30);


glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-1.5f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.25f,0.25f,2.25f,15,15);
glPopMatrix();

//green flower
glTranslatef(-1.5f, 0.4f, -7.0f);  // Move right and into the screen
glColor3f(0.0f,1.0f,0.0f);
gluSphere(qd,0.9f,30,30);


glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-3.0f,-2.4f,-7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.25f,0.25f,2.25f,15,15);
glPopMatrix();

//red flower
glTranslatef(-3.0f, 0.0f, -7.0f);  // Move right and into the screen
glColor3f(1.0f,0.0f,0.0f);
gluSphere(qd,0.9f,30,30);

glPushMatrix();
glColor3f(0.5f, 0.35f, 0.05f);
glTranslatef(-1.0f,-2.4f,7.0f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
glShadeModel(GL_FLAT);
gluCylinder(qd,0.25f,0.25f,2.25f,15,15);
glPopMatrix();
//yellow flower
glTranslatef(-1.0f, 0.0f, 7.0f);  // Move right and into the screen
glColor3f(1.0f,1.0f,0.0f);
gluSphere(qd,0.9f,30,30);


gluDeleteQuadric(qd);
glDisable(GL_CLIP_PLANE1);
   glutSwapBuffers();  // Swap the front and back frame buffers (double buffering)

}
