#ifndef SNOWMAN_H
#define SNOWMAN_H
//#include "RenderableObject.h"

class Snowman
{
    public:
       // Snowman(float id, Location& location,float p_radius, float speed );
       // Snowman(float id, Location& location, float p_radius, float speed, int* colour);
        Snowman();
        Snowman(float bx,float by,float bz,float radius,float radius2);


       // void update();
        void render();
        void moveBeeLeft();
        void moveBeeRight();
        void moveBeeUp();
        void moveBeeDown();
        void moveBeeForward();
        void moveBeeBackward();
    private:
        float bx,by,bz,radius,radius2;
       // Location c_loc; // central position
       // float p_radius; // patrol distance
        //float speed;
       // float angle;  // orientation for radial patrolling
       // int lut;      // last update time
       // int direction;
        //float ph_limit;
        //float nh_limit;
        //int colour[3]; // colour

        void drawSnowman();
       // void update_linear();
        //void update_radial();

};

#endif // SNOWMAN_H
