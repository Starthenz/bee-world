#ifndef HOUSE_H
#define HOUSE_H


class House
{
    public:
        House();

        float x,y,z;
        House(float x, float y,float z);
        void render();

    protected:
    private:

    void drawHouse();
    void drawRoof();
    void drawWindows();
};

#endif // HOUSE_H
