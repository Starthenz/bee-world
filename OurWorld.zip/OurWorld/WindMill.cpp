#include "WindMill.h"
//#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
//#include "WindMill.h"
#include <iostream>
#include <GL/glu.h>

WindMill::WindMill()
{
    //ctor
}


WindMill::WindMill(float x,float y,float z,float cy,float angle,float radius)
{
    this->x=x;
    this->y=y;
    this->z=z;
    this->cy=cy;
    this->angle=angle;
    this->radius=radius;


}
void WindMill::render(){
glPushMatrix();
glRotated(180,0,1,0);
glTranslated(x,y,z);
drawWindmill();
glPopMatrix();
}
void WindMill::drawWindmill() {
 glPushMatrix();
   //glTranslatef(1.5f, 0.0f, -7.0f);  // Move right and into the screen

GLUquadricObj*qobj;
qobj=gluNewQuadric();
//glShadeModel(GL_FLAT);
glPushMatrix();
glTranslatef(0,-3.5f,-0.5f);
glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
//glShadeModel(GL_FLAT);88
glColor3f(0.5f, 0.99f, 0.5f);
gluCylinder(qobj,0.25f,0.25f,cy,15,15);
glPopMatrix();


   glRotatef(angle, 0.0f, 0.0f, 1.0f);

   glBegin(GL_QUADS);
   // Front face  (z = 1.0f)

      glColor3f(0.0f, 1.0f, 0.0f);
      glVertex3f(-0.25f,  0.25f, 0.25f);
     //
      glColor3f(0.0f, 0.0f, 1.0f);     // Red
      glVertex3f( 0.25f,  0.25f, 0.25f);

      glColor3f(0.0f, 1.0f, 0.0f);
      glVertex3f( 0.25f, -0.25f, 0.25f);

       glColor3f(0.0f, 0.0f, 1.0f);
      glVertex3f(-0.25f, -0.25f, 0.25f);

      // Back face (z = -1.0f)

      glColor3f(0.0f, 1.0f, 0.0f);
      glVertex3f( 0.25f,  0.25f, -0.25f);

     //
      glColor3f(0.0f, 0.0f, 1.0f);     // Yellow
      glVertex3f( 0.25f, -0.25f, -0.25f);

       glColor3f(0.0f, 1.0f, 0.0f);
       glVertex3f(-0.25f, -0.25f, -0.25f);

       glColor3f(0.0f, 0.0f, 1.0f);
      glVertex3f(-0.25f,  0.25f, -0.25f);


   glEnd();// End of drawing color-cube



   glBegin(GL_TRIANGLES);  // Begin drawing the pyramid with 4 triangles

   //TOP PYRAMID
      // Front
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f( 0.0f, 2.25f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(-0.25f, 0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(0.25f, 0.25f, 0.25f);

      // Right
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(0.0f, 2.25f, 0.0f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(0.25f, 0.25f, 0.25f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(0.25f, 0.25f, -0.25f);

      // Back
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(0.0f, 2.25f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(0.25f, 0.25f, -0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(-0.25f, 0.25f, -0.25f);

      // Left
      glColor3f(1.0f,0.0f,0.0f);       // Red
      glVertex3f( 0.0f, 2.25f, 0.0f);
      glColor3f(0.0f,0.0f,1.0f);       // Blue
      glVertex3f(-0.25f,0.25f,-0.25f);
      glColor3f(0.0f,1.0f,0.0f);       // Green
      glVertex3f(-0.25f,0.25f, 0.25f);


      //LEFT PYRAMID
      //front
       glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(-2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(-0.25f, 0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(-0.25f, -0.25f, 0.25f);

       // Right
      glColor3f(1.0f, 0.0f, 1.0f);     // Red
      glVertex3f(-2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // green
      glVertex3f(-0.25f, 0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // blue
      glVertex3f(-0.25f, 0.25f, -0.25f);


       // Back
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(-2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 0.0f, 1.0f);     // blue
      glVertex3f(-0.25f, 0.25f, -0.25f);
      glColor3f(0.0f, 1.0f, 0.0f);     // green
      glVertex3f(-0.25f, -0.25f, -0.25f);

       // Left
      glColor3f(1.0f,0.0f,0.0f);       // Red
      glVertex3f( -2.25f, 0.0f, 0.0f);
      glColor3f(0.0f,0.0f,1.0f);       // green
      glVertex3f(-0.25f,-0.25f,-0.25f);
      glColor3f(0.0f,0.0f,1.0f);       // blue
      glVertex3f(-0.25f, -0.25f, 0.25f);



      //RIGHT PYRAMID


       // Front
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f( 2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(0.25f, -0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(0.25f, 0.25f, 0.25f);

       //Right
       glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 0.0f, 1.0f);     // green
      glVertex3f(0.25f, -0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // blue
      glVertex3f(0.25f, -0.25f, -0.25f);

       // Back
      glColor3f(0.0f, 0.0f, 1.0f);     // Red
      glVertex3f(2.25f, 0.0f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // blue
      glVertex3f(0.25f, 0.25f, -0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // green
      glVertex3f(0.25f, -0.25f, -0.25f);

       // Left
      glColor3f(0.0f,0.0f,1.0f);       // Red
      glVertex3f( 2.25f, 0.0f, 0.0f);
      glColor3f(0.0f,1.0f,0.0f);       // green
      glVertex3f(0.25f,0.25f,-0.25f);
      glColor3f(0.0f,0.0f,1.0f);       // blue
      glVertex3f(0.25f, 0.25f, 0.25f);

//BOTTOM PYRAMID

       // Front
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f( 0.0f, -2.25f, 0.0f);
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f(0.25f, -0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(-0.25f, -0.25f, 0.25f);


       //Right
       glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(0.0f, -2.25f, 0.0f);
      glColor3f(0.0f, 0.0f, 1.0f);     // green
      glVertex3f(0.25f, -0.25f, 0.25f);
      glColor3f(0.0f, 0.0f, 1.0f);     // blue
      glVertex3f(0.25f, -0.25f, -0.25f);

       // Back
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f(0.0f, -2.25f, 0.0f);
      glColor3f(0.0f, 0.0f, 1.0f);     // blue
      glVertex3f(0.25f, -0.25f, -0.25f);
      glColor3f(0.0f, 1.0f, 0.0f);     // green
      glVertex3f(-0.25f, -0.25f, -0.25f);

       // Left
      glColor3f(1.0f,0.0f,0.0f);       // Red
      glVertex3f( 0.0f, -2.25f, 0.0f);
      glColor3f(0.0f,1.0f,0.0f);       // green
      glVertex3f(-0.25f,-0.25f,-0.25f);
      glColor3f(0.0f,0.0f,1.0f);       // blue
      glVertex3f(-0.25f, -0.25f, 0.25f);


   glEnd();   // Done drawing the pyramid

    angle += 20.999f;
    glPopMatrix();
   glutSwapBuffers();// Swap the front and back frame buffers (double buffering)

}
