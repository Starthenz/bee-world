#ifndef FLOWER_H
#define FLOWER_H


class Flower
{
    public:
        float x;
        float y;
        float z;
        float radius;
        Flower();
        //virtual ~Flower();
        Flower(float x,float y,float z,float radius);
        void render();
    protected:

    private:

        void drawFlower();
};

#endif // FLOWER_H
