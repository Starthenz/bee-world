#ifndef EXPLODE_H
#define EXPLODE_H
#define NUM_PARTICLES    1000        /* Number of particles  */
#define NUM_DEBRIS       10           /* Number of debris     */
#include<GL/glut.h>
class Explode
{
    public:
        int      wantNormalize = 0;   /* Speed vector normalization flag */
        int      wantPause = 0;       /* Pause flag */
        int      fuel = 0;                /* "fuel" of the explosion */
            struct particleData
    {
        float   position[3];
        float   speed[3];
        float   color[3];
    };

    typedef struct particleData    particleData;

    struct debrisData
    {
      float   position[3];
      float   speed[3];
      float   orientation[3];        /* Rotation angles around x, y, and z axes */
      float   orientationSpeed[3];
      float   color[3];
      float   scale[3];
    };
    typedef struct debrisData    debrisData;

    particleData     particles[NUM_PARTICLES];
    debrisData       debris[NUM_DEBRIS];
        Explode();
        float dest[3];
        float x;
        float y;
        float z;
        void newSpeed (float dest[3]);
        void render();
        void newExplosion (float x,float y,float z);
        void update();
    protected:
    private:
};

#endif // EXPLODE_H
