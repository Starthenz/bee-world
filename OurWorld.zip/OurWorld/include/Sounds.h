#ifndef SOUNDS_H
#define SOUNDS_H


class Sounds
{
    public:
        Sounds();
        virtual ~Sounds();
    protected:
    private:
};

#endif // SOUNDS_H
