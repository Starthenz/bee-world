#include "Sound.h"
#include <iostream>
#include <windows.h>
#include "MMSystem.h"
#include "Sounds.h"

Sound :: Sound()
{

}

void Sound :: beeSound(){
    PlaySound(TEXT("\\C:\\Users\\thendo\\Documents\\FinalYearStuff\\advancedProgramming\\cplusplusCodePractice\\OurWorld\\bin\\Debug\\bee2.wav"), NULL, SND_ASYNC);
}



