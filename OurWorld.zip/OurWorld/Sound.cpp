#include "Sound.h"
#include <iostream>
#include <windows.h>
#include "MMSystem.h"

Sound :: Sound()
{

}

void Sound :: beeSound(){
    PlaySound(TEXT("bee2.wav"), NULL, SND_ASYNC);
}
void Sound :: tokenSound(){
    PlaySound(TEXT("lifeup.wav"), NULL, SND_ASYNC);
}


