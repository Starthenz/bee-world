#ifndef SOUND_H
#define SOUND_H


class Sound {
    public :
        Sound();
        void beeSound();
    private :

};

#endif // SOUND_H
