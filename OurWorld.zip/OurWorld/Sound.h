#ifndef SOUND_H
#define SOUND_H


class Sound {
    public :
        Sound();
        void beeSound();
        void tokenSound();
    private :

};

#endif // SOUND_H
