#include "World.h"
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include<ctime>
#include "time.h"
#include "BeePlayer.h"
#include "RivalBee.h"
#include "WindMill.h"
#include <vector>
#include "Flower.h"
//#include "Sprinkler.h"
#include "Tree.h"
#include "Person.h"
#include "Tokens.h"

#define _number_of_enemies_  10
#define _number_of_block_    10

using namespace std;
class Explode
{
#define NUM_PARTICLES    1000        /* Number of particles  */
#define NUM_DEBRIS       10           /* Number of debris     */
    int      wantNormalize = 0;   /* Speed vector normalization flag */
    int      wantPause = 0;       /* Pause flag */
    int      fuel = 0;                /* "fuel" of the explosion */

    struct particleData
    {
        float   position[3];
        float   speed[3];
        float   color[3];
    };
    typedef struct particleData    particleData;

    struct debrisData
    {
      float   position[3];
      float   speed[3];
      float   orientation[3];        /* Rotation angles around x, y, and z axes */
      float   orientationSpeed[3];
      float   color[3];
      float   scale[3];
    };
    typedef struct debrisData    debrisData;

    particleData     particles[NUM_PARTICLES];
    debrisData       debris[NUM_DEBRIS];

  public:
  Explode(){}

 void newSpeed (float dest[3])
{
  float    x;
  float    y;
  float    z;
  float    len;

  x = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
  y = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
  z = (2.0 * ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;

  /*
   * Normalizing the speed vectors gives a "fireball" effect
   *
   */

  if (wantNormalize)
    {
      len = sqrt (x * x + y * y + z * z);

      if (len)
	{
	  x = x / len;
	  y = y / len;
	  z = z / len;
	}
    }

  dest[0] = x;
  dest[1] = y;
  dest[2] = z;
}

 void render()
 {
    int i;
      glPushMatrix ();

      glDisable (GL_LIGHTING);
      glDisable (GL_DEPTH_TEST);

      glBegin (GL_POINTS);

      for (i = 0; i < NUM_PARTICLES; i++)
	{
	  glColor3fv (particles[i].color);
	  glVertex3fv (particles[i].position);
	}

      glEnd ();

      glPopMatrix ();

      glEnable (GL_LIGHTING);
      glEnable (GL_LIGHT0);
      glEnable (GL_DEPTH_TEST);

      glNormal3f (0.0, 0.0, 1.0);

      for (i = 0; i < NUM_DEBRIS; i++)
	{
	  glColor3fv (debris[i].color);

	  glPushMatrix ();

	  glTranslatef (debris[i].position[0],
			debris[i].position[1],
			debris[i].position[2]);

	  glRotatef (debris[i].orientation[0], 1.0, 0.0, 0.0);
	  glRotatef (debris[i].orientation[1], 0.0, 1.0, 0.0);
	  glRotatef (debris[i].orientation[2], 0.0, 0.0, 1.0);

	  glScalef (debris[i].scale[0],
		    debris[i].scale[1],
		    debris[i].scale[2]);

	  glBegin (GL_TRIANGLES);
	  glVertex3f (0.0, 0.5, 0.0);
	  glVertex3f (-0.25, 0.0, 0.0);
	  glVertex3f (0.25, 0.0, 0.0);
	  glEnd ();

	  glPopMatrix ();
	}
 }

 void newExplosion (float x,float y,float z)
 {
  int    i;

  for (i = 0; i < NUM_PARTICLES; i++)
    {
      particles[i].position[0] = x;
      particles[i].position[1] = y;
      particles[i].position[2] = z;

      particles[i].color[0] = 1.0;
      particles[i].color[1] = 1.0;
      particles[i].color[2] = 0.5;

      newSpeed (particles[i].speed);
    }

  for (i = 0; i < NUM_DEBRIS; i++)
    {
      debris[i].position[0] = x;
      debris[i].position[1] = y;
      debris[i].position[2] = z;

      debris[i].orientation[0] = 0.0;
      debris[i].orientation[1] = 0.0;
      debris[i].orientation[2] = 0.0;

      debris[i].color[0] = 0.7;
      debris[i].color[1] = 0.7;
      debris[i].color[2] = 0.7;

      debris[i].scale[0] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
      debris[i].scale[1] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;
      debris[i].scale[2] = (2.0 *
			    ((GLfloat) rand ()) / ((GLfloat) RAND_MAX)) - 1.0;

      newSpeed (debris[i].speed);
      newSpeed (debris[i].orientationSpeed);
    }
  fuel = 100;

}

  void update(void)
  {
  int    i;

  if (!wantPause)
    {
      if (fuel > 0)
	{
	  for (i = 0; i < NUM_PARTICLES; i++)
	    {
	      particles[i].position[0] += particles[i].speed[0] * 0.2;
	      particles[i].position[1] += particles[i].speed[1] * 0.2;
	      particles[i].position[2] += particles[i].speed[2] * 0.2;

	      particles[i].color[0] -= 1.0 / 500.0;
	      if (particles[i].color[0] < 0.0)
		{
		  particles[i].color[0] = 0.0;
		}

	      particles[i].color[1] -= 1.0 / 100.0;
	      if (particles[i].color[1] < 0.0)
		{
		  particles[i].color[1] = 0.0;
		}

	      particles[i].color[2] -= 1.0 / 50.0;
	      if (particles[i].color[2] < 0.0)
		{
		  particles[i].color[2] = 0.0;
		}
	    }

	  for (i = 0; i < NUM_DEBRIS; i++)
	    {
	      debris[i].position[0] += debris[i].speed[0] * 0.1;
	      debris[i].position[1] += debris[i].speed[1] * 0.1;
	      debris[i].position[2] += debris[i].speed[2] * 0.1;

	      debris[i].orientation[0] += debris[i].orientationSpeed[0] * 10;
	      debris[i].orientation[1] += debris[i].orientationSpeed[1] * 10;
	      debris[i].orientation[2] += debris[i].orientationSpeed[2] * 10;
	    }

	  --fuel;
	}

  glutPostRedisplay ();
}


}
}explode;
bool exploding = false;
World::World()
 {

         distance=0;
         bee=new BeePlayer(-8.0f, 2.0f, -10.0f,1.58f,1.98f);
         rB=new RivalBee(-12.0f,2.0f,-55.0f,0.5f,3.0f,3.0f,0.7f);
         person=new Person(-8.0f,0.0f,-18.0f,0.65f);
         windmill=new WindMill(12.0f,0.0f,19.0f,3.5f,0.0f,2.5f);
         tree=new Tree(0.15f,1.0f,-8.0f,-4.0f,3.0f);
         sound=new Sound();
         token=new Tokens(8.0f,2.0f,0.0f,1.2f,1.5f,0.7f);
         flower=new Flower(-12.0f,0.0f,-19.0f,0.1f);
 }


void World::render(){
    glPushMatrix();
      bee->render();
      sound->beeSound();
    glPopMatrix();

//    sprinkler.DrawFountain();
    glPushMatrix();
        person->render();
    glPopMatrix();
    glPushMatrix();
        rB->render();
    glPopMatrix();
    glPushMatrix();
        tree->render();
    glPopMatrix();
    glPushMatrix();
        windmill->render();
    glPopMatrix();
    glPushMatrix();
        token->render();
    glPopMatrix();
    glPushMatrix();
        flower->render();
    glPopMatrix();
            if(exploding)
    {
      explode.render();
        token->innerRadius*=0;
        token->outterRadius*=0;
    }
}
void World::update(){
 if(exploding)
        explode.update();
    glutPostRedisplay();
}
void World::tokenDetection(){
    float dist=pow((bee->x-token->x),2)+pow((bee->y-token->y),2)+pow((bee->z-token->z),2);
    dist=sqrt(dist);
    if(dist<=bee->radius+token->radius){
        explode.newExplosion(token->x,token->y,token->z);
        exploding=true;
    }
}


bool World::detectCollision2(){
    //r1= bee->radius+windmill->radius;
    r2= bee->radius+person->radius;
    //r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-person->x),2)+pow((bee->z-person->z),2);//+pow((bee->y-person->y),2)z
    dist = sqrt(dist);

    if(dist<=r2){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r2   = "<< r2<<endl;
    return isColliding;
}
bool World::detectCollision1(){
    r1= bee->radius+windmill->radius;
    //r2= bee->radius+person->radius;
    //r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-windmill->x),2)+pow((bee->y-windmill->y),2)+pow((bee->z-windmill->z),2);
    dist = sqrt(dist);

    if(dist<=r1){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r1   = "<< r1<<endl;
    return isColliding;
}
bool World::detectCollision3(){

    r3= bee->radius+rB->radius;
    bool isColliding=false;
    float dist=pow((bee->x-rB->x),2)+pow((bee->y-rB->y),2)+pow((bee->z-rB->z),2);
    dist = sqrt(dist);

    if(dist<=r3){
        isColliding=true;
    }
    else{
        isColliding=false;
    }

    //
    cout<<"is colliding "<< isColliding<<endl;
    cout<<"dist = "<< dist <<endl;
    cout<<"r3   = "<< r3<<endl;
    return isColliding;
}

void World::moveBeeLeft(){
tokenDetection();
 if(!detectCollision2()){
    bee->moveBeeLeft();
 }
// else if(!detectCollision2()){
//    bee->moveBeeLeft();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeLeft();
// }
else{
    bee->z=-10.0;
 }
 }
void World::moveBeeRight(){
tokenDetection();
     if(!detectCollision2()){
    bee->moveBeeRight();
 }
// else if(!detectCollision2()){
//    bee->moveBeeRight();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeRight();
// }
else{
    bee->z=-10.0;
 }
}

void World::moveBeeUp(){
tokenDetection();
bee->moveBeeUp();
}
void World::moveBeeDown(){
tokenDetection();
if(bee->y>=-0.3){
bee->moveBeeDown();
}

}
void World::moveBeeForward(){
    tokenDetection();
if(bee->z<=45){
  if(!detectCollision2()){
    bee->moveBeeForward();
 }
// else if(!detectCollision2()){
//    bee->moveBeeForward();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeForward();
// }
else{
     bee->z=-10.0;
 }
 }
}
void World::moveBeeBackward(){
    tokenDetection();
if(bee->z>=-45){
 if(!detectCollision2()){
   bee->moveBeeBackward();
 }
// else if(!detectCollision2()){
//    bee->moveBeeBackward();
// }
//  else if(!detectCollision3()){
//    bee->moveBeeBackward();
// }
else{
    bee->z=-10.0;
 }
}
}
