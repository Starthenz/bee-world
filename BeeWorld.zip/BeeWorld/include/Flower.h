#ifndef FLOWER_H
#define FLOWER_H


class Flower
{
    public:
        float x;
        float y;
        float z;
        Flower();
        //virtual ~Flower();
        Flower(float x,float y,float z);
        void render();
    protected:

    private:

        void drawFlower();
};

#endif // FLOWER_H
