#ifndef RIVALBEE_H
#define RIVALBEE_H
#include "BeePlayer.h"

class RivalBee
{
    public:
        RivalBee();
        RivalBee(float x,float y,float z,float rivalBeeSize,float speed,float p_radius);
        void render();
        void update();
    protected:
    private:
        float x;
        float y;
        float z;
        float speed;
        float nh_limit;
        float ph_limit;
        float p_radius;
        int lut;      // last update time
        int direction;
        float rivalBeeSize;
        void drawRivalBee();
        void update_linear();

};

#endif // RIVALBEE_H
