#ifndef INVISIBLEENTITY_H
#define INVISIBLEENTITY_H


class InvisibleEntity
{
    public:
        float height;
        float width;
        float breadth;
        float objNo;
        float x;
        float y;
        float z;
        InvisibleEntity();
        InvisibleEntity(float x, float y, float z,float breadth,float height,float width,float objNo);
        void render();
        void drawEntity();
    protected:
    private:


};

#endif // INVISIBLEENTITY_H
