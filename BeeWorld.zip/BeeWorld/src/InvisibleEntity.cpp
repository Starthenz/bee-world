#include "InvisibleEntity.h"
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <iostream>
#include<math.h>

InvisibleEntity::InvisibleEntity()
{
    //ctor
}

InvisibleEntity::InvisibleEntity(float x, float y, float z,float breadth,float height,float width,float objNo){
this->x=x;
this->y=y;
this->z=z;
this->breadth=breadth;
this->width=width;
this->height=height;
this->objNo=objNo;
}



void InvisibleEntity::render(){

    glPushMatrix();
        glTranslated(x,y,z);
        drawEntity();
    glPopMatrix();
}

void InvisibleEntity::drawEntity(){
    glPushMatrix();
        glColor3f(1,0.8,1);
        glScaled(breadth,height,width);
        glutWireCube(1);
    glPopMatrix();


}
